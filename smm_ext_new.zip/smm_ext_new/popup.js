
$('.tieit_login').click(function(e){

  alert('ok');
})