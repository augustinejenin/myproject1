chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
      if ( request.action == "startLightbox" ) {
  
            background = document.createElement('div');
            background.id = "lightbox_background";
            lightbox = document.createElement('div');
            lightbox.id = "lightbox_extension";
            
            
            lightbox.innerHTML = '<h1>Hello, world.</h1> <input type="file">';
                   
                
            document.body.appendChild(background);
            background.appendChild( lightbox );
            closeScriptureLightbox = function() {
                
                var lb = document.getElementById('lightbox_background');
                lb.parentNode.removeChild( lb );
                
            }
            button = document.createElement('button');
            button.onclick=closeScriptureLightbox;
            button.textContent='Close';
            lightbox.appendChild(button);
            sendResponse({farewell: "goodbye"});
  
      }
      if (request.action == "startLightboxext"){
            

            background = document.createElement('div');
            background.id = "lightbox_background";
            lightbox = document.createElement('div');
            lightbox.id = "lightbox_extension";
            
            
            lightbox.innerHTML ='<body class="tieit_body_pop"> <div id="tieit_page_content"> <div class="tieit_title"> <img src="login-logo.png" alt="Tieit Logo"> </div> <div class="tieit_form"> <h4 class="tieit_form_head">Login to Your <span class="tieit_name">TieiT</span> Account</h4> <div class="tieit_alert-error" style="display:none"> <button class="tieit_alert_close">X</button> <p></p> </div> <div id="loader" style="display:none"> <img src="https://s-media-cache-ak0.pinimg.com/originals/01/8d/2a/018d2ac351d2f2de9b77e870f29894e1.gif"> </div> <form> <input class="w-80" type="text" id="tieit_username" placeholder="Username" value=""/> <input class="w-80" type="password" id="tieit_password" placeholder="Password" value=""/> <button type="button" class="tieit_login w-80" id="tieit_login">Login</button> </form> </div> <div class="tieit_forget"><a href="#">Forgot</a> password?</div> <!-- <a id="logout" href="#">Logout</a> --> </div> </div> </body>';
                   
                
            document.body.appendChild(background);
            background.appendChild(lightbox);
            closeScriptureLightbox = function() {
                
                var lb = document.getElementById('lightbox_background');
                lb.parentNode.removeChild( lb );
                
            }
            button = document.createElement('button');
            button.onclick=closeScriptureLightbox;
            button.textContent='Close';
            lightbox.appendChild(button);
            sendResponse({farewell: "goodbye"});
  
      }

      $('.tieit_login').click(function(e){

          $('#tieit_page_content').empty();
          $('#tieit_page_content').append('success');
      })
  });



