<?php 
header('Access-Control-Allow-Origin: *');
echo 1;exit;
?>