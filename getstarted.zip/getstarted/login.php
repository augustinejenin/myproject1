  <div class="form">
    <h2>Login to your account</h2>
    <form>
      <input type="text" id="username" placeholder="Username" value=""/>
      <input type="password" id="password" placeholder="Password"/>
      <button class="login" id="login">Login</button>
    </form>
  </div>
  <div class="cta"><a href="#">Forgot your password?</a></div>