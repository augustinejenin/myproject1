

    chrome.runtime.onMessage.addListener(function (message) {
          var user=getCookie("test");
          if(user!=""){
              var xhr = new XMLHttpRequest();
                xhr.open("GET", "http://localhost/chrome/getstarted/table.php", true);
                xhr.onreadystatechange = function() {
                  if (xhr.readyState == 4) {
                    document.getElementById('test').innerHTML = xhr.responseText;
                  }
              }
                xhr.send();
            
          }
      
    });
    var link = document.getElementById('login');
    // onClick's logic below:
    link.addEventListener('click', function() {

       var username=document.getElementById('username').value;
       var password=document.getElementById('password').value;
      
      if (username==""){
        
          alert("Name can't be blank");  
        return false;  
      }else if(password==""){  
          alert("Password must be at least 6 characters long.");  
        return false;  
        }  
       var xhr = new XMLHttpRequest();
       xhr.open("GET", "http://localhost/chromeplugin/test.php", true);
        xhr.onreadystatechange = function() {
          if (xhr.readyState == 4) {
            setCookie('test','test',30);
           // chrome.runtime.reload();
          }
      }
        xhr.send();
        
    });

         var anchor = document.getElementById('logout');
    
         anchor.addEventListener('click', function() {
           setCookie('test',"",-1);
           chrome.runtime.reload();
         });

    
/*    
document.addEventListener('DOMContentLoaded', function() {
        var anchor1 = document.getElementById('list');
        
    if(anchor1){
         anchor1.addEventListener('click', function() {

            
        });

      }
});*/
    

    function setCookie(cname,cvalue,exdays) {

        var d = new Date();
        d.setTime(d.getTime() + (exdays*24*60*60*1000));
        var expires = "expires=" + d.toGMTString();
        document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
    }

    function getCookie(cname) {

        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for(var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }
   



