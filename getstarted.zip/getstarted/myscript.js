
/*chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse)
    { 
        if (request.action == "openNewTab")
          
            chrome.extension.sendMessage('sdsd');
    }
);*/
chrome.runtime.sendMessage(document.title);

