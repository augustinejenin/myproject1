    
 var base_url="https://api-stg.tieit.io";
    //chrome.runtime.onMessage.addListener(function (message) {
               
      
      /* chrome.storage.local.get('Urlselected', function (result) {
              Urlselected = result.Urlselected;
              if(Urlselected){

                  $('.tieit_post_textarea').val(Urlselected);
              }
      });*/
   // });
    /* var tokenarray=[];
    chrome.storage.local.get('token', function (result) {

              token = result.token;
              tokenarray.push(token);
              if(token){
              
                  $('#tieit_page_content').empty();

                  $.ajax({

                      url: base_url+'/smm',
                      type:'GET',
                      data: {'token': token},
                      crossDomain: true,
                      contentType: "application/x-www-form-urlencoded",
                      async: false,
                      dataType: 'html',
                     // cache: false,
                      success: function (response) {
                           
                            $('#tieit_page_content').append(response);
                       
                      },
                      error: function (ErrorResponse) {
                         
                           var obj= jQuery.parseJSON(ErrorResponse.responseText); 
                           if(obj.status_code==401){
                              chrome.storage.local.clear();
                              chrome.runtime.reload();
                           }    
                      }
                  
                  });
            
              }
          });

     chrome.storage.local.get('username', function (result) {
              username = result.username;
              if(username){

                  $('#tieit_username').val(username);
              }
      });
     chrome.storage.local.get('password', function (result) {
              password = result.password;
              if(password){
                  $('#tieit_password').val(password);
              }
          });

     chrome.storage.local.get('loginerror', function (result) {
              loginerror = result.loginerror;
              if(loginerror){
                //alert('ok');
              
                $('.tieit_alert-error').show();   
                $('.tieit_alert_close').next('p').empty();
                $('.tieit_alert_close').next('p').text(loginerror);
                setTimeout(function(){
                     chrome.storage.local.clear();
                 }, 1000);
               
              }
      });

   /* chrome.extension.onMessage.addListener(function(request, sender, sendResponse) {
        console.log('request from background');

        if(request.method == 'countDown') {
            console.log(request.seconds);
            sendResponse({secondbutton: 'sdfdsfd'});
            //countDown(request.id);
        }

       
    });*/
   

     /*document.addEventListener("DOMContentLoaded", function(event) {

        //var bgPage = chrome.extension.getBackgroundPage();
        if (!Notification) {
          alert('Desktop notifications not available in your browser. Try Chromium.'); 
          return;
        }

        if (Notification.permission !== "granted")
          Notification.requestPermission();

        chrome.storage.local.get('textselected', function (result) {
              textselected = result.textselected;
              if(textselected){

                  var everythingLoaded = setInterval(function() {

                      if (/loaded|complete/.test(document.readyState)) {
                        clearInterval(everythingLoaded);
                       $('.tieit_post_textarea').val(textselected);
                     }

                    }, 10);
      
                  
              }
      });

      chrome.storage.local.get('Urlselected', function (result) {
              Urlselected = result.Urlselected;
              if(Urlselected){
                   var everythingLoaded = setInterval(function() {

                      if (/loaded|complete/.test(document.readyState)) {
                        clearInterval(everythingLoaded);
                       $('.tieit_post_textarea').val(Urlselected);
                     }

                    }, 10);
                 
              }
      });*/
        $('.tieit_login').click(function(){
              alert('ok');
              var email=$('#tieit_username').val();
              var password=$('#tieit_password').val();
               
              if (!ValidateEmail(email)) {

                $('.tieit_alert-error').show();
                $('.tieit_alert_close').next('p').empty();
                $('.tieit_alert_close').next('p').text('Please enter valid email address');
                return false;
              }
               if(password==""){  

                $('.tieit_alert-error').show();   
                $('.tieit_alert_close').next('p').empty();
                $('.tieit_alert_close').next('p').text('Please enter password');
                return false;
                }  
            


                $.ajax({

                      url: base_url+'/auth/login',
                      type:'POST',
                      data: {'email': email,'password':password},
                      crossDomain: true,
                      contentType: "application/x-www-form-urlencoded",
                      async: false,
                      dataType: 'json',
                      //cache: false,
                      success: function (response) {
                        $('#tieit_username').val('sdfdsafd');
                        if(response.token){
                         
                          chrome.storage.local.set({'token': response.token});

                        }
                      },
                      error: function (ErrorResponse) {
                        
                          var obj= jQuery.parseJSON(ErrorResponse.responseText);
                          if(obj.message=='Unauthorized'){

                              chrome.storage.local.set({'loginerror': 'Incorrect Login'});
                                
                          }
                      }
                     
                });

        })

        $('.tieit_alert_close').click(function(){

            $('.tieit_alert-error').hide();   

        })

        $("#tieit_username").keyup(function(event) {
                var username = $(this).val();
                chrome.storage.local.set({'username': username});
        });

        $("#tieit_password").keyup(function(event) {
                var password = $(this).val();
                chrome.storage.local.set({'password': password});
        });


        var everythingLoaded = setInterval(function() {

              if (/loaded|complete/.test(document.readyState)) {
                clearInterval(everythingLoaded);
                   
                    $('#logout').click(function(){
                       
                        chrome.storage.local.clear();
                        chrome.runtime.reload();
                    })
                   
                    $('.tieit_shedule_it').click(function() {
                        $('.tieit_time_wrap').slideDown();
                        $('.tieit_button_wrap').slideUp();
                    });

                    $('.tieit_time_cancel').click(function() {
                        $('.tieit_time_wrap').slideUp();
                        $('.tieit_button_wrap').slideDown();
                    });
                    $('[name="tieit_page_rd"]').change(function() {
                      if($(this).val() == 1){
                        $('.tieit_smm_cat_hidden_input').val('');
                        $('.tieit_btn-que-grp').hide();
                        $('.tieit_btn-post-grp').show();
                        $('.tieit_indv-account').removeClass('move-it');
                        $('.tieit_catg-container').removeClass('move-it');
                      }else{
                        
                        $("#tieit_category").val("0").trigger("change");
                        $('.tieit_catg-container').addClass('move-it');
                        $('.tieit_indv-account').addClass('move-it');
                        $('.tieit_btn-que-grp,.tieit_button_wrap').show();
                        $('.tieit_btn-post-grp,.tieit_time_wrap').hide();
                      }
                    });

                    $('.tieit_cancel_btn').click(function(){
                          window.close();
                    })

                    //post now api
                    $('.tieit_ext_postnow').click(function(){

                       
                        var message=$('.tieit_post_textarea').val();
                        var profile_sel = [];
                         $("li.tieit_profs").each(function(){
                            
                              if($($(this).find('.tieit_profs_chk')).is(":checked"))
                              {
                                  profile_sel.push($(this).find('.tieit_profs_chk').val());
                                
                              }
                              
                          });
                         
                        if(profile_sel.length<1){
                           
                            createNotifications('OOPs','Please select atleast One profile','2000');
                            return false;

                        }

                        if(message==""){
                            createNotifications('OOPs','Please enter post content','2000');
                            return false;

                        }

                        var selected_profiles=profile_sel.join();
                        var user_id=$("#hidden_user_id").val();
                        var token=tokenarray[0];
                        alert(selected_profiles);
                        $.ajax({

                                url: base_url+'/auth/authsuccess',
                                type:'POST',
                                data: {'profiles': selected_profiles,'user_id':user_id,'token':token,'message':message},
                                crossDomain: true,
                                contentType: "application/x-www-form-urlencoded",
                                async: false,
                               // dataType: 'json',
                                //cache: false,
                                success: function (response) {
                                   createNotifications('Success','Content posted to the selected profiles','3000');
                                },
                                error: function (ErrorResponse) {
                                  
                                   createNotifications('OOPs','Content Can not posted','3000');
                                }
                       
                          });

                       

                    })


                    //schedule api
                      $('.tieit_ext_schedulepost').click(function(){

                        var message=$('.tieit_post_textarea').val();
                        var date   =$('#sdate').val();
                        var time   =$('#act_time').val();
                        var profile_sel = [];
                         $("li.tieit_profs").each(function(){
                            
                              if($($(this).find('.tieit_profs_chk')).is(":checked"))
                              {
                                  profile_sel.push($(this).find('.tieit_profs_chk').val());
                                
                              }
                              
                          });

                        if(profile_sel.length<1){
                         
                            createNotifications('OOPs','Please select atleast One profile','2000');
                            return false;

                        }

                        if(message==""){
                            createNotifications('OOPs','Please enter post content','2000');
                            return false;

                        }
                        if(date==""){
                            createNotifications('OOPs','Please select the date','2000');
                            return false;

                        }
                        if(time==""){
                            createNotifications('OOPs','Please enter the time','2000');
                            return false;

                        }
                        
                        var selected_profiles=profile_sel.join();
                        var user_id=$("#hidden_user_id").val();
                        var token=tokenarray[0];
                        $.ajax({

                                url: base_url+'/auth/authsuccess',
                                type:'POST',
                                data: {'profiles': selected_profiles,'user_id':user_id,'token':token,'message':message,'date':date,'time':time},
                                crossDomain: true,
                                contentType: "application/x-www-form-urlencoded",
                                async: false,
                               // dataType: 'json',
                                //cache: false,
                                success: function (response) {
                                   createNotifications('Success','Post scheduled successfully','3000');
                                },
                                error: function (ErrorResponse) {
                                   createNotifications('OOPs','Post could not be schedule!','3000');
                                }
                       
                          });

                       

                    })

                     //schedule api (add to queue)
                    $('.tieit_ext_queue').click(function(){
                        
                        var cat=$('#tieit_category').val();
                        var message=$('.tieit_post_textarea').val();
                        var type=$(this).attr('data-queue');
                       
                        if(cat==0){
                         
                            createNotifications('OOPs','Please select atleast One category','2000');
                            return false;

                        }
                        if(message==""){
                            createNotifications('OOPs','Please enter post content','2000');
                            return false;

                        }
                       
                        var user_id=$("#hidden_user_id").val();
                        var token=tokenarray[0];
                        $.ajax({

                                url: base_url+'/auth/authsuccess',
                                type:'POST',
                                data: {'cat_id': cat,'user_id':user_id,'token':token,'message':message,'type':type},
                                crossDomain: true,
                                contentType: "application/x-www-form-urlencoded",
                                async: false,
                               // dataType: 'json',
                                //cache: false,
                                success: function (response) {
                                   createNotifications('Success','Post scheduled successfully','3000');
                                },
                                error: function (ErrorResponse) {
                                   createNotifications('OOPs','Post could not be schedule!','3000');
                                }
                       
                          });

                       

                    })

                  //show character count onkeyup
                  $(".tieit_post_textarea").keyup(function() {

                            $('.smm_twittercount').show();
                            var acc_array=[];
                            var catval=$('.tieit_smm_cat_hidden_input').val();

                            if(catval){
                                acc_array.push(catval);
                                console.log(acc_array);
                            }else{
                                $("li.tieit_profs").each(function(){
                                    if($($(this).find('.tieit_profs_chk')).is(":checked"))
                                    {
                                        acc_array.push($(this).attr('acc-type'));
                                    }
                                });
                            }
                            
                            var message=$('.tieit_post_textarea').val();
                            urls=message.match(/((?:(http|https|Http|Https|rtsp|Rtsp):\/\/(?:(?:[a-zA-Z0-9\$\-\_\.\+\!\*\'\(\)\,\;\?\&\=]|(?:\%[a-fA-F0-9]{2})){1,64}(?:\:(?:[a-zA-Z0-9\$\-\_\.\+\!\*\'\(\)\,\;\?\&\=]|(?:\%[a-fA-F0-9]{2})){1,25})?\@)?)?((?:(?:[a-zA-Z0-9][a-zA-Z0-9\-]{0,64}\.)+(?:(?:aero|arpa|asia|a[cdefgilmnoqrstuwxz])|(?:biz|b[abdefghijmnorstvwyz])|(?:cat|com|coop|c[acdfghiklmnoruvxyz])|d[ejkmoz]|(?:edu|e[cegrstu])|f[ijkmor]|(?:gov|g[abdefghilmnpqrstuwy])|h[kmnrtu]|(?:info|int|i[delmnoqrst])|(?:jobs|j[emop])|k[eghimnrwyz]|l[abcikrstuvy]|(?:mil|mobi|museum|m[acdghklmnopqrstuvwxyz])|(?:name|net|n[acefgilopruz])|(?:org|om)|(?:pro|p[aefghklmnrstwy])|qa|r[eouw]|s[abcdeghijklmnortuvyz]|(?:tel|travel|t[cdfghjklmnoprtvwz])|u[agkmsyz]|v[aceginu]|w[fs]|y[etu]|z[amw]))|(?:(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9])\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[0-9])))(?:\:\d{1,5})?)(\/(?:(?:[a-zA-Z0-9\;\/\?\:\@\&\=\#\~\-\.\+\!\*\'\(\)\,\_])|(?:\%[a-fA-F0-9]{2}))*)?(?:\b|$)/gi);
                            if($.inArray('Twitter',acc_array)!= -1){
                             
                                 if(urls){
                                    
                                      var post_content=[];
                                      post_content.push(message);
                                      $.each(urls, function (key, val) {

                                         var url=val;
                                         var result= post_content[key].replace(url,'');
                                         post_content.push(result);
                                      });
                                                       
                                      var newpost=post_content.pop();//get the last array value
                                      var url_length=urls.length*23;
                                      var current_count=140 -newpost.length;
                                      var new_count=current_count-parseInt(url_length);
                                      var remain=url_length-parseInt(current_count);
                                      
                                     
                                      $('.smm_twittercount').text(new_count);
                                      
                                      if(new_count<0){
                                       
                                        $('.tieit_btn').addClass('tieit_disable_btn');
                                        $('.smm_twittercount').addClass('smm_twittercount-warning');
                                        return false;

                                      }else{

                                        $('.tieit_btn').removeClass('tieit_disable_btn');
                                        $('.smm_twittercount ').removeClass('smm_twittercount-warning');

                                      }
                                  
                                    
                                  }else{

                                       var message = $('.tieit_post_textarea').val();
                                       $('.smm_twittercount').text(140  - message.length);
                                       if(message.length > 140) {
                                            $('.tieit_btn').addClass('tieit_disable_btn');
                                            $('.smm_twittercount').addClass('smm_twittercount-warning');
                                            return false;
                                       }else{
                                            $('.tieit_btn').removeClass('tieit_disable_btn');
                                            $('.smm_twittercount ').removeClass('smm_twittercount-warning');
                                       }

                                  }

                      }else{
                           $('.tieit_btn').removeClass('tieit_disable_btn');
                           $('.smm_twittercount').hide();
                      }
                  });

                  //show cahracetr count when selecting twitter profile
                  $( ".tieit_profs" ).change(function() {

                            $('.smm_twittercount').show();
                            var acc_array=[];
                            $("li.tieit_profs").each(function(){
                                if($($(this).find('.tieit_profs_chk')).is(":checked"))
                                {
                                    acc_array.push($(this).attr('acc-type'));
                                }
                            });
                            var message=$('.tieit_post_textarea').val();
                            urls=message.match(/((?:(http|https|Http|Https|rtsp|Rtsp):\/\/(?:(?:[a-zA-Z0-9\$\-\_\.\+\!\*\'\(\)\,\;\?\&\=]|(?:\%[a-fA-F0-9]{2})){1,64}(?:\:(?:[a-zA-Z0-9\$\-\_\.\+\!\*\'\(\)\,\;\?\&\=]|(?:\%[a-fA-F0-9]{2})){1,25})?\@)?)?((?:(?:[a-zA-Z0-9][a-zA-Z0-9\-]{0,64}\.)+(?:(?:aero|arpa|asia|a[cdefgilmnoqrstuwxz])|(?:biz|b[abdefghijmnorstvwyz])|(?:cat|com|coop|c[acdfghiklmnoruvxyz])|d[ejkmoz]|(?:edu|e[cegrstu])|f[ijkmor]|(?:gov|g[abdefghilmnpqrstuwy])|h[kmnrtu]|(?:info|int|i[delmnoqrst])|(?:jobs|j[emop])|k[eghimnrwyz]|l[abcikrstuvy]|(?:mil|mobi|museum|m[acdghklmnopqrstuvwxyz])|(?:name|net|n[acefgilopruz])|(?:org|om)|(?:pro|p[aefghklmnrstwy])|qa|r[eouw]|s[abcdeghijklmnortuvyz]|(?:tel|travel|t[cdfghjklmnoprtvwz])|u[agkmsyz]|v[aceginu]|w[fs]|y[etu]|z[amw]))|(?:(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9])\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[0-9])))(?:\:\d{1,5})?)(\/(?:(?:[a-zA-Z0-9\;\/\?\:\@\&\=\#\~\-\.\+\!\*\'\(\)\,\_])|(?:\%[a-fA-F0-9]{2}))*)?(?:\b|$)/gi);
                            if($.inArray('Twitter',acc_array)!= -1){
                                 if(urls){
                                    
                                      var post_content=[];
                                      post_content.push(message);
                                      $.each(urls, function (key, val) {

                                         var url=val;
                                         var result= post_content[key].replace(url,'');
                                         post_content.push(result);
                                      });
                                                       
                                      var newpost=post_content.pop();//get the last array value
                                      var url_length=urls.length*23;
                                      var current_count=140 -newpost.length;
                                      var new_count=current_count-parseInt(url_length);
                                      var remain=url_length-parseInt(current_count);
                                      
                                     
                                      $('.smm_twittercount').text(new_count);
                                      
                                      if(new_count<0){
                                       
                                        $('.tieit_btn').addClass('tieit_disable_btn');
                                        $('.smm_twittercount').addClass( "smm_twittercount-warning" );
                                        
                                        return false;

                                      }else{

                                        $('.tieit_btn').removeClass('tieit_disable_btn');
                                        $('.smm_twittercount ').removeClass("smm_twittercount-warning");

                                      }
                                  
                                    
                                  }else{

                                       var message = $('.tieit_post_textarea').val();
                                       $('.smm_twittercount').text(140  - message.length);
                                       if(message.length > 140) {
                                            $('.tieit_btn').addClass('tieit_disable_btn');
                                            $('.smm_twittercount').addClass( "smm_twittercount-warning" );
                                            return false;
                                       }else{
                                            $('.tieit_btn').removeClass('tieit_disable_btn');
                                            $('.smm_twittercount ').removeClass("smm_twittercount-warning");
                                       }

                                  }

                      }else{
                           $('.tieit_btn').removeClass('tieit_disable_btn');
                           $('.smm_twittercount').hide();
                      }


                  });

                  //show charater count when selecting category
                  $(".tieit_cat_select").change(function() {
                     
                      var cat=$(this).val();
                      
                      var account_array=[];
                      if(cat==4){
                         account_array.push('2');
                      }else{
                         account_array.push('1');
                      }
                      
                      $('.tieit_smm_cat_hidden_input').val('1');
                      
                    //  var account_array = jQuery.parseJSON(account_array);
                      console.log(account_array);
                      if($.inArray('2',account_array)!= -1){
                        
                          $('.tieit_smm_cat_hidden_input').val('Twitter'); 
                          $('.smm_twittercount').show();
                          var message=$('.tieit_post_textarea').val();
                          urls=message.match(/((?:(http|https|Http|Https|rtsp|Rtsp):\/\/(?:(?:[a-zA-Z0-9\$\-\_\.\+\!\*\'\(\)\,\;\?\&\=]|(?:\%[a-fA-F0-9]{2})){1,64}(?:\:(?:[a-zA-Z0-9\$\-\_\.\+\!\*\'\(\)\,\;\?\&\=]|(?:\%[a-fA-F0-9]{2})){1,25})?\@)?)?((?:(?:[a-zA-Z0-9][a-zA-Z0-9\-]{0,64}\.)+(?:(?:aero|arpa|asia|a[cdefgilmnoqrstuwxz])|(?:biz|b[abdefghijmnorstvwyz])|(?:cat|com|coop|c[acdfghiklmnoruvxyz])|d[ejkmoz]|(?:edu|e[cegrstu])|f[ijkmor]|(?:gov|g[abdefghilmnpqrstuwy])|h[kmnrtu]|(?:info|int|i[delmnoqrst])|(?:jobs|j[emop])|k[eghimnrwyz]|l[abcikrstuvy]|(?:mil|mobi|museum|m[acdghklmnopqrstuvwxyz])|(?:name|net|n[acefgilopruz])|(?:org|om)|(?:pro|p[aefghklmnrstwy])|qa|r[eouw]|s[abcdeghijklmnortuvyz]|(?:tel|travel|t[cdfghjklmnoprtvwz])|u[agkmsyz]|v[aceginu]|w[fs]|y[etu]|z[amw]))|(?:(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9])\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[1-9]|0)\.(?:25[0-5]|2[0-4][0-9]|[0-1][0-9]{2}|[1-9][0-9]|[0-9])))(?:\:\d{1,5})?)(\/(?:(?:[a-zA-Z0-9\;\/\?\:\@\&\=\#\~\-\.\+\!\*\'\(\)\,\_])|(?:\%[a-fA-F0-9]{2}))*)?(?:\b|$)/gi);
                            
                          if(urls){
                            
                                var post_content=[];
                                post_content.push(message);
                                $.each(urls, function (key, val) {

                                     var url=val;
                                     var result= post_content[key].replace(url,'');
                                     post_content.push(result);

                                });

                                var newpost=post_content.pop();//get the last array value
                                var url_length=urls.length*23;
                                var current_count=140 -newpost.length;
                                var new_count=current_count-parseInt(url_length);
                                var remain=url_length-parseInt(current_count);
                                $('.smm_twittercount').text(new_count);
                                if(new_count<0){
                                 
                                  $('.tieit_btn').addClass('tieit_disable_btn');
                                  $('.smm_twittercount').addClass( "smm_twittercount-warning" );
                                  return false;

                                }else{

                                  $('.tieit_btn').removeClass('tieit_disable_btn');
                                  $('.smm_twittercount').removeClass("smm_twittercount-warning");

                                }
                          
                            
                          }else{

                              var message = $('.tieit_post_textarea').val();
                              $('.smm_twittercount').text(140  - message.length);
                              if(message.length > 140) {
                                  $('.tieit_btn').addClass('tieit_disable_btn');
                                  $('.smm_twittercount').addClass( "smm_twittercount-warning" );
                                  return false;
                                }else{
                                  $('.tieit_btn').removeClass('tieit_disable_btn');
                                  $('.smm_twittercount ').removeClass("smm_twittercount-warning");
                                }
                          }
                                  
                              
                        }else{
                           
                            $('.tieit_btn').removeClass('tieit_disable_btn');
                            $('.smm_twittercount').hide();
                              
                        }



                      
                    });

              
             }

          }, 100);

         
            
        });

   

    function ValidateEmail(email) {
        var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return expr.test(email);
    };

    function removeElementsBySelector(selector) {
        Array.from(document.querySelectorAll(selector)).forEach(element => {
            element.remove();
        });
    }
        






   
   



